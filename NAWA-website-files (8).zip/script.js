/* NAWA Creative Media — bilingual interactions and ambient canvas effects */
"use strict";

const translations = {
en:{
navAbout:"About",navServices:"Services",navProcess:"Process",navPackages:"Packages",navFaq:"FAQs",navContact:"Contact",navCta:"Let's Talk ↗",
heroEyebrow:"INDEPENDENT CREATIVE AGENCY · UAE",heroTitle:'Ideas that take root.<br><span class="gradient-text">Brands that grow.</span>',heroDescription:"We bring strategy, creativity and digital thinking together to help ambitious businesses build meaningful brands and move forward with confidence.",heroPrimary:"Start a conversation ↗",heroSecondary:"Explore our services ↓",heroTrust:"Proudly based in the UAE · Working across the GCC",heroBottomLeft:"STRATEGY · DESIGN · DIGITAL",heroBottomRight:"DISCOVER NAWA ↓",
visualLabel:"THE NAWA APPROACH",visualSmall:"OUR PHILOSOPHY",visualTitle:"Growth begins<br>with intention.",floatOneTitle:"Creative thinking",floatOneText:"Ideas with purpose",floatTwoTitle:"Meaningful growth",floatTwoText:"Built for the long term",
aboutTag:"01 / THE THINKING",aboutTitle:'Rooted in meaning.<br><span class="muted">Designed for growth.</span>',aboutLabel:"WHY THE NAME NAWA?",aboutQuote:"“Every meaningful journey begins with a seed. What matters is how you nurture it.”",aboutDescription:"Inspired by the Arabic word for seed, NAWA represents the belief that lasting growth starts with strong roots. We combine thoughtful strategy and creative execution to help businesses build brands with purpose and potential that extends beyond the moment.",aboutSignature:"A different way to grow.",
servicesTag:"02 / WHAT WE DO",servicesTitle:'Creative solutions.<br><span class="muted">Clear direction.</span>',servicesIntro:"From the first idea to the final experience, we help bring every part of your brand together.",
service1Title:"Brand Identity",service1Text:"Distinctive visual identities that communicate who you are and what you stand for.",service1Bottom:"STRATEGY · IDENTITY",service2Title:"Social Media",service2Text:"Thoughtful social media management that gives your brand a consistent voice.",service2Bottom:"CONTENT · COMMUNITY",service3Title:"Content Creation",service3Text:"Creative photography, video and visual content designed around your brand.",service3Bottom:"PHOTO · VIDEO",service4Title:"Web Design",service4Text:"Modern, responsive digital experiences built to make a lasting impression.",service4Bottom:"DESIGN · DEVELOPMENT",service5Title:"Digital Marketing",service5Text:"Focused campaigns that connect your business with the right audience.",service5Bottom:"CAMPAIGNS · REACH",service6Title:"Creative Direction",service6Text:"A clear creative vision that brings your brand's communication together.",service6Bottom:"CONCEPT · DIRECTION",serviceCtaLabel:"HAVE SOMETHING IN MIND?",serviceCtaTitle:"Let's grow something meaningful.",serviceCtaText:"Tell us about your idea and let's explore what's possible.",serviceCtaLink:"Discuss your project ↗",
processTag:"03 / HOW WE WORK",processTitle:'A thoughtful process.<br><span class="muted">A clearer direction.</span>',process1Title:"Discover",process1Text:"We learn about your business, your audience and what you want to achieve.",process2Title:"Define",process2Text:"We establish a clear direction, priorities and a strategy for your project.",process3Title:"Create",process3Text:"We turn the agreed direction into considered creative work and experiences.",process4Title:"Grow",process4Text:"We help you move forward with consistency, refinement and continued improvement.",
whyTag:"04 / THE NAWA DIFFERENCE",whyTitle:'More than just<br><span class="muted">good-looking work.</span>',whyIntro:"We believe effective creative work should look considered, communicate clearly and serve a real purpose.",why1Title:"Purpose before appearance",why1Text:"Every decision starts with understanding what your business actually needs.",why2Title:"Strategy meets creativity",why2Text:"We bring clear thinking and creative execution into the same conversation.",why3Title:"Built around your brand",why3Text:"Your business is different. Your creative direction should reflect that.",why4Title:"A long-term mindset",why4Text:"We focus on creating foundations that support consistent development over time.",
packagesTag:"05 / WORKING TOGETHER",packagesTitle:'The right starting point<br><span class="muted">for your next chapter.</span>',packagesIntro:"Explore a starting direction. Every engagement can be discussed around your business needs.",package1Label:"01 / ESSENTIAL",package1Title:"Foundation",package1Description:"For businesses looking to establish a clearer brand presence.",package2Label:"02 / GROWTH",package2Title:"Momentum",package2Description:"For businesses ready to develop a more consistent digital presence.",package3Label:"03 / PARTNERSHIP",package3Title:"Expansion",package3Description:"For businesses seeking a broader, connected creative and digital approach.",packagePrice:"Contact us",packageButton:"Discuss this package ↗",includesLabel:"A STARTING POINT FOR",featuredBadge:"A POPULAR STARTING DIRECTION",package1Feature1:"Initial brand consultation",package1Feature2:"Brand direction discussion",package1Feature3:"Creative recommendations",package1Feature4:"Project scope proposal",package2Feature1:"Brand and content direction",package2Feature2:"Social media planning",package2Feature3:"Creative content concepts",package2Feature4:"Digital growth consultation",package3Feature1:"Integrated brand strategy",package3Feature2:"Creative direction",package3Feature3:"Digital experience planning",package3Feature4:"Ongoing growth discussions",packageNote:"Package descriptions are indicative starting points, not fixed service commitments. Final scope and pricing are confirmed after consultation.",
faqTag:"06 / GOOD TO KNOW",faqTitle:'A few things<br><span class="muted">you might be wondering.</span>',faqIntro:"Have another question? We're happy to talk through your ideas.",faqLink:"Get in touch ↗",faq1Question:"What does NAWA do?",faq1Answer:"NAWA is a creative and digital growth agency offering branding, social media, content creation, web design, digital marketing and creative direction.",faq2Question:"Where is NAWA based?",faq2Answer:"NAWA is based in the United Arab Emirates and works with businesses across the UAE and the wider GCC.",faq3Question:"Can I request an individual service?",faq3Answer:"Yes. You can discuss an individual service or a combination of services based on your goals and requirements.",faq4Question:"How much do your services cost?",faq4Answer:"Pricing depends on the project scope, deliverables and timeline. Contact us for a discussion and a tailored proposal.",faq5Question:"How do we get started?",faq5Answer:"Send us a message on WhatsApp or Instagram. Tell us a little about your business and what you are looking to achieve.",faq6Question:"How long does a project take?",faq6Answer:"Timelines vary depending on the service and project scope. We will discuss the expected timeline before work begins.",
contactTag:"07 / THE NEXT STEP",contactTitle:"Every great idea<br>starts somewhere.",contactDescription:"Tell us what you're building, where you want to go and how we can help you get there.",contactWhatsApp:"Start on WhatsApp ↗",contactInstagram:"Follow our Instagram ↗",contactLocation:"BASED IN THE UAE · OPEN TO THE GCC",backTop:"BACK TO TOP ↑",copyright:"© 2026 NAWA Creative Media. All rights reserved.",footerMeaning:"نوى — Ideas rooted. Growth in motion."
},
ar:{
navAbout:"من نحن",navServices:"خدماتنا",navProcess:"آلية العمل",navPackages:"الباقات",navFaq:"الأسئلة الشائعة",navContact:"تواصل معنا",navCta:"لنتحدث ↗",
heroEyebrow:"وكالة إبداعية مستقلة · الإمارات",heroTitle:'أفكارٌ تنمو من الجذور.<br><span class="gradient-text">وعلاماتٌ تصنع أثراً.</span>',heroDescription:"نجمع بين الاستراتيجية والإبداع والتفكير الرقمي لمساعدة الشركات الطموحة على بناء علامات تجارية ذات معنى والانطلاق بثقة نحو المستقبل.",heroPrimary:"لنبدأ الحوار ↗",heroSecondary:"اكتشف خدماتنا ↓",heroTrust:"نفخر بوجودنا في الإمارات · ونعمل في مختلف دول الخليج",heroBottomLeft:"استراتيجية · تصميم · حلول رقمية",heroBottomRight:"اكتشف نوى ↓",
visualLabel:"منهجية نوى",visualSmall:"فلسفتنا",visualTitle:"النمو يبدأ<br>من فكرة واضحة.",floatOneTitle:"تفكير إبداعي",floatOneText:"أفكار تحمل هدفاً",floatTwoTitle:"نمو حقيقي",floatTwoText:"رؤية للمستقبل",
aboutTag:"01 / الفكرة",aboutTitle:'جذور تحمل معنى.<br><span class="muted">ورؤية تصنع النمو.</span>',aboutLabel:"لماذا اسم نوى؟",aboutQuote:"«كل رحلة ذات معنى تبدأ ببذرة، وما يصنع الفرق حقاً هو كيف نرعاها لتنمو.»",aboutDescription:"استُلهم اسم نوى من معنى البذرة في اللغة العربية، تعبيراً عن إيماننا بأن النمو المستدام يبدأ من أساس قوي. نجمع بين التفكير الاستراتيجي والتنفيذ الإبداعي لمساعدة الشركات على بناء علامات تجارية واضحة الهوية، تحمل قيمة حقيقية وتملك القدرة على التطور.",aboutSignature:"طريق مختلف نحو النمو.",
servicesTag:"02 / ماذا نقدم",servicesTitle:'حلول إبداعية.<br><span class="muted">ورؤية واضحة.</span>',servicesIntro:"من الفكرة الأولى إلى التجربة النهائية، نعمل على بناء صورة متكاملة لعلامتك التجارية.",
service1Title:"الهوية التجارية",service1Text:"هويات بصرية مميزة تعبّر عن شخصية علامتك التجارية وقيمها.",service1Bottom:"الاستراتيجية · الهوية",service2Title:"إدارة التواصل الاجتماعي",service2Text:"إدارة مدروسة لحسابات التواصل الاجتماعي تمنح علامتك حضوراً متناسقاً.",service2Bottom:"المحتوى · المجتمع",service3Title:"صناعة المحتوى",service3Text:"تصوير فوتوغرافي وإنتاج فيديو ومحتوى بصري يعكس هوية علامتك.",service3Bottom:"التصوير · الفيديو",service4Title:"تصميم المواقع",service4Text:"تجارب رقمية عصرية ومتجاوبة تترك انطباعاً مميزاً لدى زوارك.",service4Bottom:"التصميم · التطوير",service5Title:"التسويق الرقمي",service5Text:"حملات تسويقية مدروسة تربط أعمالك بالجمهور المناسب.",service5Bottom:"الحملات · الوصول",service6Title:"التوجيه الإبداعي",service6Text:"رؤية إبداعية واضحة توحّد أسلوب التواصل والتعبير عن علامتك.",service6Bottom:"الفكرة · التوجيه",serviceCtaLabel:"لديك فكرة ترغب في تنفيذها؟",serviceCtaTitle:"لننطلق معاً نحو نمو يصنع الفرق.",serviceCtaText:"شاركنا فكرتك ودعنا نستكشف الإمكانيات المتاحة.",serviceCtaLink:"ناقش مشروعك ↗",
processTag:"03 / كيف نعمل",processTitle:'خطوات مدروسة.<br><span class="muted">واتجاه أكثر وضوحاً.</span>',process1Title:"نكتشف",process1Text:"نتعرف على أعمالك وجمهورك والأهداف التي تسعى إلى تحقيقها.",process2Title:"نحدد",process2Text:"نضع التوجه المناسب والأولويات والاستراتيجية التي يحتاجها مشروعك.",process3Title:"نبدع",process3Text:"نحوّل الرؤية المتفق عليها إلى أعمال إبداعية وتجارب متكاملة.",process4Title:"ننمو",process4Text:"نساعدك على المضي قدماً من خلال الاستمرارية والتطوير والتحسين.",
whyTag:"04 / ما يميز نوى",whyTitle:'أكثر من مجرد<br><span class="muted">تصميم جميل.</span>',whyIntro:"نؤمن بأن العمل الإبداعي الناجح يجب أن يجمع بين الجمال والوضوح والهدف الحقيقي.",why1Title:"الهدف قبل المظهر",why1Text:"نبدأ كل قرار بفهم احتياجات عملك وما يحتاجه فعلياً.",why2Title:"الاستراتيجية تلتقي بالإبداع",why2Text:"نجمع بين التفكير الواضح والتنفيذ الإبداعي في رؤية واحدة.",why3Title:"مصمم حول علامتك",why3Text:"لكل مشروع طابعه الخاص، ويجب أن يعكس توجهه الإبداعي هذه الخصوصية.",why4Title:"رؤية بعيدة المدى",why4Text:"نركز على بناء أسس تدعم التطور المستمر والنمو على المدى الطويل.",
packagesTag:"05 / شراكة العمل",packagesTitle:'البداية المناسبة<br><span class="muted">لفصلك القادم.</span>',packagesIntro:"اكتشف توجهاتنا الأولية، ويمكن مناقشة تفاصيل كل تعاون بما يتناسب مع احتياجات عملك.",package1Label:"01 / الأساس",package1Title:"التأسيس",package1Description:"للشركات التي ترغب في بناء حضور أوضح لعلامتها التجارية.",package2Label:"02 / النمو",package2Title:"الانطلاقة",package2Description:"للشركات المستعدة لتطوير حضور رقمي أكثر استمرارية.",package3Label:"03 / الشراكة",package3Title:"التوسع",package3Description:"للشركات التي تبحث عن رؤية إبداعية ورقمية أكثر تكاملاً.",packagePrice:"تواصل معنا",packageButton:"ناقش هذه الباقة ↗",includesLabel:"نقطة بداية تشمل",featuredBadge:"توجه مقترح للانطلاق",package1Feature1:"استشارة أولية للعلامة التجارية",package1Feature2:"مناقشة التوجه والهوية",package1Feature3:"توصيات إبداعية",package1Feature4:"مقترح لنطاق المشروع",package2Feature1:"توجه العلامة التجارية والمحتوى",package2Feature2:"تخطيط التواصل الاجتماعي",package2Feature3:"أفكار المحتوى الإبداعي",package2Feature4:"استشارة للنمو الرقمي",package3Feature1:"استراتيجية متكاملة للعلامة",package3Feature2:"التوجيه الإبداعي",package3Feature3:"تخطيط التجربة الرقمية",package3Feature4:"مناقشات مستمرة حول النمو",packageNote:"هذه الباقات توجهات أولية وليست التزامات ثابتة بالخدمات. يتم تحديد نطاق العمل والتكلفة النهائية بعد الاستشارة.",
faqTag:"06 / معلومات تهمك",faqTitle:'بعض الأسئلة<br><span class="muted">التي قد تخطر ببالك.</span>',faqIntro:"هل لديك استفسار آخر؟ يسعدنا الاستماع إلى أفكارك.",faqLink:"تواصل معنا ↗",faq1Question:"ما الخدمات التي تقدمها نوى؟",faq1Answer:"نوى وكالة للإبداع والنمو الرقمي، تقدم خدمات الهوية التجارية وإدارة التواصل الاجتماعي وصناعة المحتوى وتصميم المواقع والتسويق الرقمي والتوجيه الإبداعي.",faq2Question:"أين يقع مقر نوى؟",faq2Answer:"نوى مقرها في دولة الإمارات العربية المتحدة، وتعمل مع الشركات في مختلف أنحاء الإمارات ودول مجلس التعاون الخليجي.",faq3Question:"هل يمكن طلب خدمة واحدة فقط؟",faq3Answer:"بالتأكيد. يمكنك مناقشة خدمة منفردة أو مجموعة من الخدمات وفقاً لأهدافك ومتطلبات مشروعك.",faq4Question:"ما تكلفة خدماتكم؟",faq4Answer:"تختلف التكلفة بحسب نطاق المشروع والمخرجات المطلوبة والمدة الزمنية. تواصل معنا لمناقشة احتياجاتك والحصول على مقترح مناسب.",faq5Question:"كيف يمكنني البدء؟",faq5Answer:"أرسل لنا رسالة عبر واتساب أو إنستغرام، وشاركنا نبذة عن نشاطك التجاري وما تطمح إلى تحقيقه.",faq6Question:"كم يستغرق تنفيذ المشروع؟",faq6Answer:"تختلف المدة بحسب نوع الخدمة ونطاق المشروع. سنناقش الجدول الزمني المتوقع قبل البدء في التنفيذ.",
contactTag:"07 / الخطوة القادمة",contactTitle:"كل فكرة عظيمة<br>لها بداية.",contactDescription:"أخبرنا عمّا تعمل على بنائه، وإلى أين تطمح للوصول، وكيف يمكننا مساعدتك.",contactWhatsApp:"ابدأ المحادثة عبر واتساب",contactInstagram:"تابعنا على إنستغرام",contactLocation:"مقرنا الإمارات · نعمل في دول الخليج",backTop:"العودة للأعلى ↑",copyright:"© 2026 نوى للإبداع الرقمي. جميع الحقوق محفوظة.",footerMeaning:"نوى — جذور تحمل معنى، ونمو يصنع الفرق."
}};

const languageToggle=document.getElementById("languageToggle");
function setLanguage(lang){
  const language=translations[lang]?lang:"en";
  document.documentElement.lang=language;
  document.documentElement.dir=language==="ar"?"rtl":"ltr";
  document.querySelectorAll("[data-i18n]").forEach(el=>{
    const value=translations[language][el.dataset.i18n];
    if(value!==undefined) el.innerHTML=value;
  });
  languageToggle.textContent=language==="en"?"العربية":"English";
  languageToggle.setAttribute("aria-label",language==="en"?"Switch to Arabic":"Switch to English");
  try{localStorage.setItem("nawa-language",language)}catch(e){}
  document.title=language==="ar"?"نوى | وكالة إبداعية ونمو رقمي":"NAWA Creative Media | Creative & Digital Growth Agency";
}
let saved="en";try{saved=localStorage.getItem("nawa-language")||"en"}catch(e){}
setLanguage(saved);
languageToggle.addEventListener("click",()=>setLanguage(document.documentElement.lang==="en"?"ar":"en"));

const navbar=document.getElementById("navbar");
const menuToggle=document.getElementById("menuToggle");
const navLinks=document.getElementById("navLinks");
function closeMenu(){navLinks.classList.remove("open");menuToggle.classList.remove("active");menuToggle.setAttribute("aria-expanded","false");document.body.classList.remove("menu-open")}
menuToggle.addEventListener("click",()=>{const open=navLinks.classList.toggle("open");menuToggle.classList.toggle("active",open);menuToggle.setAttribute("aria-expanded",String(open));document.body.classList.toggle("menu-open",open)});
navLinks.querySelectorAll("a").forEach(a=>a.addEventListener("click",closeMenu));
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeMenu()});
window.addEventListener("resize",()=>{if(innerWidth>768)closeMenu()});
window.addEventListener("scroll",()=>navbar.classList.toggle("scrolled",scrollY>35),{passive:true});

document.querySelectorAll(".faq-question").forEach(button=>button.addEventListener("click",()=>{
  const wasOpen=button.getAttribute("aria-expanded")==="true";
  document.querySelectorAll(".faq-question").forEach(other=>{other.setAttribute("aria-expanded","false");other.nextElementSibling.hidden=true});
  if(!wasOpen){button.setAttribute("aria-expanded","true");button.nextElementSibling.hidden=false}
}));

const reduce=matchMedia("(prefers-reduced-motion: reduce)").matches;
const revealItems=document.querySelectorAll(".section-heading,.about-card,.service-card,.process-item,.why-card,.package-card,.faq-item,.contact-content");
if(!reduce&&"IntersectionObserver" in window){
  revealItems.forEach(el=>el.classList.add("reveal"));
  const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add("visible");observer.unobserve(entry.target)}}),{threshold:.12});
  revealItems.forEach(el=>observer.observe(el));
}

/* Shared animation lifecycle */
function canvasLoop(canvas,drawFrame){
  if(!canvas||reduce)return;
  const ctx=canvas.getContext("2d");let w=0,h=0,dpr=1,raf=0,last=0;
  function resize(){const r=canvas.getBoundingClientRect();w=r.width;h=r.height;dpr=Math.min(devicePixelRatio||1,2);canvas.width=Math.max(1,w*dpr);canvas.height=Math.max(1,h*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);drawFrame.resize?.(w,h)}
  function frame(t){raf=0;if(document.hidden)return;ctx.clearRect(0,0,w,h);drawFrame(ctx,t,w,h);raf=requestAnimationFrame(frame)}
  function start(){if(!raf&&!document.hidden)raf=requestAnimationFrame(frame)}
  function stop(){if(raf)cancelAnimationFrame(raf);raf=0}
  window.addEventListener("resize",resize);document.addEventListener("visibilitychange",()=>document.hidden?stop():start());resize();start();
  return {ctx,resize};
}

/* Canvas 1 — soft particles, connecting lines, pointer attraction and click ripples */
(()=>{
  const canvas=document.getElementById("particleCanvas");if(!canvas||reduce)return;
  let w=innerWidth,h=innerHeight,particles=[],ripples=[],pointer={x:-999,y:-999};
  function reset(){const count=innerWidth<768?24:62;particles=Array.from({length:count},()=>({x:Math.random()*w,y:Math.random()*h,vx:(Math.random()-.5)*.24,vy:(Math.random()-.5)*.24,r:.6+Math.random()*1.3,a:.15+Math.random()*.3}))}
  canvasLoop(canvas,(ctx,t)=>{
    particles.forEach((p,i)=>{
      p.x+=p.vx;p.y+=p.vy;if(p.x<0||p.x>w)p.vx*=-1;if(p.y<0||p.y>h)p.vy*=-1;
      const dx=pointer.x-p.x,dy=pointer.y-p.y,d=Math.hypot(dx,dy);if(d<130&&d>0){p.x-=dx*.002;p.y-=dy*.002}
      ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fillStyle=`rgba(210,181,137,${p.a})`;ctx.fill();
      for(let j=i+1;j<particles.length;j++){const q=particles[j],dist=Math.hypot(p.x-q.x,p.y-q.y);if(dist<112){ctx.beginPath();ctx.moveTo(p.x,p.y-scrollY*.018);ctx.lineTo(q.x,q.y-scrollY*.018);ctx.strokeStyle=`rgba(200,168,121,${.075*(1-dist/112)})`;ctx.stroke()}}
    });
    ripples=ripples.filter(r=>r.a>.02);ripples.forEach(r=>{r.radius+=1.5;r.a*=.965;ctx.beginPath();ctx.arc(r.x,r.y,r.radius,0,Math.PI*2);ctx.strokeStyle=`rgba(227,201,158,${r.a})`;ctx.stroke()});
  });
  canvas.addEventListener("pointermove",e=>{pointer.x=e.clientX;pointer.y=e.clientY},{passive:true});
  canvas.addEventListener("pointerleave",()=>{pointer.x=-999;pointer.y=-999});
  window.addEventListener("click",e=>{if(!e.target.closest("a,button"))ripples.push({x:e.clientX,y:e.clientY,radius:0,a:.5})});
  window.addEventListener("resize",()=>{w=innerWidth;h=innerHeight;reset()});reset();
})();

/* Canvas 2 — floating lanterns and birds in the contact area */
(()=>{
  const canvas=document.getElementById("contactCanvas");if(!canvas||reduce)return;
  let w=0,h=0,lanterns=[],birds=[],bursts=[],pointer={x:-999,y:-999};
  function reset(){const r=canvas.getBoundingClientRect();w=r.width;h=r.height;lanterns=Array.from({length:innerWidth<768?4:8},()=>({x:Math.random()*w,y:Math.random()*h,s:.12+Math.random()*.2,phase:Math.random()*6,drift:(Math.random()-.5)*.2}));birds=Array.from({length:4},()=>({x:Math.random()*w,y:Math.random()*h*.55,s:.18+Math.random()*.3,p:Math.random()*6}))}
  canvasLoop(canvas,(ctx,t)=>{
    lanterns.forEach(l=>{const dx=l.x-pointer.x,dy=l.y-pointer.y,d=Math.hypot(dx,dy);let px=0,py=0;if(d<140&&d>0){px=dx/d*9;py=dy/d*9}const x=l.x+Math.sin(t*.001+l.phase)*7+px,y=l.y+Math.cos(t*.001+l.phase)*4+py;const glow=ctx.createRadialGradient(x,y,1,x,y,23);glow.addColorStop(0,"rgba(227,201,158,.25)");glow.addColorStop(1,"rgba(227,201,158,0)");ctx.fillStyle=glow;ctx.beginPath();ctx.arc(x,y,23,0,Math.PI*2);ctx.fill();ctx.strokeStyle="rgba(200,168,121,.65)";ctx.strokeRect(x-3,y-5,6,10);ctx.beginPath();ctx.moveTo(x,y+5);ctx.lineTo(x,y+15);ctx.stroke();l.y-=l.s;l.x+=l.drift;if(l.y<-25){l.y=h+25;l.x=Math.random()*w}});
    birds.forEach(b=>{b.x+=b.s;if(b.x>w+20){b.x=-20;b.y=Math.random()*h*.5}const wing=Math.sin(t*.006+b.p)*4;ctx.beginPath();ctx.moveTo(b.x-7,b.y);ctx.quadraticCurveTo(b.x-3,b.y-wing,b.x,b.y);ctx.quadraticCurveTo(b.x+3,b.y-wing,b.x+7,b.y);ctx.strokeStyle="rgba(200,168,121,.55)";ctx.stroke()});
    bursts=bursts.filter(b=>b.a>.02);bursts.forEach(b=>{b.r+=1.6;b.a*=.95;ctx.beginPath();ctx.arc(b.x,b.y,b.r,0,Math.PI*2);ctx.strokeStyle=`rgba(227,201,158,${b.a})`;ctx.stroke()});
  });
  canvas.addEventListener("pointermove",e=>{const r=canvas.getBoundingClientRect();pointer.x=e.clientX-r.left;pointer.y=e.clientY-r.top},{passive:true});
  canvas.addEventListener("pointerleave",()=>{pointer.x=-999;pointer.y=-999});
  canvas.addEventListener("pointerdown",e=>{const r=canvas.getBoundingClientRect();bursts.push({x:e.clientX-r.left,y:e.clientY-r.top,r:0,a:.8})});
  window.addEventListener("resize",reset);reset();
})();
