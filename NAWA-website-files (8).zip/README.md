# NAWA Creative Media — Static Website

A bilingual (English / Arabic) single-page website for a UAE-based creative and digital agency.

## Files
- `index.html` — semantic page structure, SEO metadata and structured data
- `style.css` — responsive design system, glass surfaces, typography and RTL styling
- `script.js` — translations, navigation, FAQ, reveal effects and canvas animations
- `logo.svg` — editable vector wordmark
- `README.md` — setup and customization instructions

## Run locally
Keep all five files in one folder and double-click `index.html`. No npm, build step, server or framework is required. Google Fonts need an internet connection; system fallbacks are provided.

## Publish with GitHub Pages
1. Create a GitHub repository.
2. Upload all five files to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`.
6. Save. GitHub Pages will publish the site.

## Customize text and translations
All bilingual strings are in the `translations` object in `script.js`, under `en` and `ar`. Keep keys aligned between languages. Elements in `index.html` use `data-i18n` keys. The language toggle updates the page language, direction and document title and remembers the choice in local storage.

The page content currently assumes NAWA Creative Media (نوى), a UAE base and GCC service area. Edit the HTML and both translation dictionaries to update the business details.

## Customize colors and fonts
Edit the CSS custom properties at the top of `style.css` in `:root`. Main palette values include `--bg`, `--bg2`, `--gold`, `--gold-light`, `--text` and `--muted`. Font variables include English display/body/mono and Arabic display/body families.

## Contact details and launch checklist
Before publishing, replace:
- `WHATSAPP_NUMBER` with the full international number, digits only (for example `9715XXXXXXXX`)
- `INSTAGRAM_HANDLE` with the real Instagram username
- `YOUR-DOMAIN` in canonical, alternate-language, Open Graph, Twitter and JSON-LD metadata
- `og-image.jpg` with a real social sharing image hosted on your domain

Confirm the service list, package inclusions, pricing, business name and Arabic copy. Package content is currently indicative and all prices say “Contact us”. No testimonials, client logos, awards or performance statistics have been invented.

## Contact form
There is no contact form in this site. If you later want one, connect a form service such as Formspree or build a backend endpoint; a static HTML page alone cannot securely receive and process form submissions.

## Motion and accessibility
The mobile navigation, one-at-a-time FAQ accordion, keyboard focus states and `prefers-reduced-motion` support are included. Canvas animations pause when the browser tab is hidden and are skipped when reduced motion is requested.
